<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                          
                                            <div class="alert alert-info"><strong><center>Add Product </center></strong></div>
                                        </div>
                                        <div class="modal-body">
                              <form  method="post" enctype="multipart/form-data">
                                
                                <hr>
								
								 <div class="control-group">
                                           <label class="control-label" for="inputEmail">Name:</label>
                                           <input type="text" name="t1" class = "form-control" placeholder="Name">
                                          
                                 </div>
                               
                                <div class="control-group">
                                    <label class="control-label" for="inputPassword">Category:</label>
                                    <div class="controls">
                                    <select type="text" name="t3" class = "form-control" placeholder="Category">

                                        <option></option>
                                        <option>all</option>
                                        <option>men</option>
                                        <option>women</option>
                                        <option>shoes</option>
                                        <option>watches</option>
                                        <option>clothes</option>
                                        <option>popular</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label" for="inputPassword">Price:</label>
                                    <div class="controls">
                                        <input type="text" name="t2"  class = "form-control" splaceholder="Price" >
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label" for="input01">Image:</label>
                                    <div class="controls">
                                        <input type="file" name="img"> 	
                                    </div>
                                </div>

								<div class = "modal-footer">
											 <button name = "sub" class="btn btn-primary">Save</button>
											<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                           

								</div>
							
									   </div>
                                     
                                          
                                      
                                    </div>
									
									  </form>  
									  
									   <?php include ('connection.php');
                                       error_reporting(1);
                            if (isset($_POST['sub'])) {

                                $prono = $_POST['t1'];
                                $price = $_POST['t2'];
                                $category = $_POST['t3'];

                                //image
                                $img=$_FILES['img']['name'];
                                {mkdir("image/$i");
//
                                move_uploaded_file($_FILES["img"]["tmp_name"], "image/$i". $_FILES["img"]["name"]);
                                }


                                mysql_query("insert into items (prono,price,category,img)
                            	values ('$prono','$price','$category','$img')
                                ") or die(mysql_error());

                                header('location:product.php');
                            }
                            ?>
									  
									  
									  
									  
                                </div>
                            </div>