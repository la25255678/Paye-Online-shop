<?php
error_reporting(1);
session_destroy();
header('location:index.php');
?>
